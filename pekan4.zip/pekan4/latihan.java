import java.util.Scanner;

public class latihan {

    public static void main(String [] args){
    Scanner.

    }

}
